#include <string>

namespace wireguard_dart {

std::wstring WriteConfigToTempFile(std::string config);

}
